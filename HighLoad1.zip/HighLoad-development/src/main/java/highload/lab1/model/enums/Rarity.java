package highload.lab1.model.enums;

public enum Rarity {
    RARE,
    SUPERRARE,
    EPIC,
    MYTHIC,
    LEGENDARY
}
