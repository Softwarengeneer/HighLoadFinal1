package highload.lab1.exception;

public class UserExistException extends Exception {
    public UserExistException(String message) {
        super(message);
    }
}
